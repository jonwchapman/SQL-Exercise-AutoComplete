AutoComplete-JqueryUI-SQL
=========================

An attempt at implementing Jquery Autocomplete with multiple values over an entire textarea.

=========================


This will be a plugin for an SQL exercise system in use for the undergraduate IS program at the University of South Alabama.
It will allow for Autocomplete functionality akin to the kind that you would find in any popular, modern IDE such as 
Visual Studio 2013, Eclipse, PHP Storm, etc.





/////   TODO   //////


Put workflow and standards into written form for use with later projects and to allow refinement.
Consider coding standards and implementing specific coding styles.
Add more to the TODO list.


Phase 1.

  Proof of concept. Hardcoded values for table and attributes.

Phase 2. 

  Dynamically insert values for tables and attributes based on the particular lesson.
  
Phase 3.

  Update values for tables and attributes automatically either on schedule or when changes are made to DB.
  
Phase 4. 

  ?????
  
